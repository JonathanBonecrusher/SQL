﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PhoneInfo;

namespace WpfApp4
{
    public partial class MainWindow : Window
    {
        List<phone> phones;
        public MainWindow()
        {
            InitializeComponent();
            //EndEditing();
            mainDataGridView.ItemsSource = DatabaseControl.GetPhonesForView();
            //companyView.ItemsSource = DataBaseControl.GetCompanyForView();
        }

        private void addButtonView_Click(object sender, RoutedEventArgs e)
        {

        }
    }
    //    private void Button_Click(object sender, RoutedEventArgs e)
    //    {
    //        DataBaseControl.AddPhone(new Phone
    //        {
    //            Title = titleView.Text,
    //            CompanyId = (companyView.SelectedItem as Company).Id,
    //            Price = Convert.ToDecimal(priceView.Text)
    //        });
    //        mainListBox.ItemsSource = null;
    //        mainListBox.ItemsSource = DataBaseControl.GetPhonesForView();
    //        titleView.Text = String.Empty;
    //        companyView.Text = String.Empty;
    //        priceView.Text = String.Empty;
    //    }

    //    private void editButton_Click(object sender, RoutedEventArgs e)
    //    {
    //        Phone tempPhone = mainListBox.SelectedItem as Phone;
    //        if (tempPhone != null)
    //        {
    //            titleView.Text = tempPhone.Title;
    //            companyView.SelectedIndex = tempPhone.CompanyId - 1;
    //            priceView.Text = tempPhone.Price.ToString();

    //            mainListBox.IsEnabled = false;
    //            addButtonView.IsEnabled = false;
    //            editButtonView.IsEnabled = false;
    //            removeButtonView.IsEnabled = false;

    //            saveEditButtonView.Visibility = Visibility.Visible;
    //            cancelEditButtonView.Visibility = Visibility.Visible;
    //        }
    //    }

    //    private void Button_Click_1(object sender, RoutedEventArgs e)
    //    {
    //        try
    //        {
    //            DataBaseControl.RemovePhone(new Phone
    //            {
    //                Title = titleView.Text,
    //                CompanyId = (companyView.SelectedItem as Company).Id,
    //                Price = Convert.ToDecimal(priceView.Text)
    //            });
    //        }
    //        catch (Exception ex)
    //        {
    //            MessageBox.Show(ex.Message);
    //        }
    //        mainListBox.ItemsSource = null;
    //        mainListBox.ItemsSource = DataBaseControl.GetPhonesForView();
    //        titleView.Text = String.Empty;
    //        companyView.Text = String.Empty;
    //        priceView.Text = String.Empty;
    //    }

       
    //    private void EndEditing()
    //    {
    //        titleView.Text = String.Empty;
    //        companyView.Text = String.Empty;
    //        priceView.Text = String.Empty;

    //        mainListBox.IsEnabled = true;
    //        addButtonView.IsEnabled = true;
    //        editButtonView.IsEnabled = true;
    //        removeButtonView.IsEnabled = true;
    //    }

    //    private void cancelEditButtonView_Click(object sender, RoutedEventArgs e) => EndEditing();

    //    private void saveEditButtonView_Click(object sender, RoutedEventArgs e)
    //    {
            
    //        try
    //        {
    //            DataBaseControl.UpdatePhone(new Phone
    //            {
    //                Title = titleView.Text,
    //                CompanyId = (companyView.SelectedItem as Company).Id,
    //                Price = Convert.ToDecimal(priceView.Text)
    //            });
    //        }
    //        catch (Exception ex)
    //        {
    //            saveEditButtonView.Visibility = Visibility.Hidden;
    //            cancelEditButtonView.Visibility = Visibility.Hidden;
    //            MessageBox.Show(ex.Message);
    //        }
    //        saveEditButtonView.Visibility = Visibility.Hidden;
    //        cancelEditButtonView.Visibility = Visibility.Hidden;
    //        mainListBox.ItemsSource = null;
    //        mainListBox.ItemsSource = DataBaseControl.GetPhonesForView();
    //        titleView.Text = String.Empty;
    //        companyView.Text = String.Empty;
    //        priceView.Text = String.Empty;

    //        EndEditing();
    //    }
    //}
}
