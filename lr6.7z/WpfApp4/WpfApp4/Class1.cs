﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneInfo
{
    public class Phone
    {
        public int Id { get; set; }
        public string Title { get; set; }

        public string CompanyId { get; set; }
        public decimal Price { get; set; }

        public Company CompanyEntity { get; set; }
    }

    public class Company
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string CEO { get; set; }
        public double Capital { get; set; }

        public List<Phone> PhonesEntities { get; set; }
    }

    public class DbAppContext : DbContext
    {
        public DbSet<Phone> Phones { get; set; }
        public DbSet<Company> Company { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseNpgsql(
                "Host=localhost;Username=postgres;Password=root;Database=kak hochesh");

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Phone>().HasOne(p => p.CompanyEntity).WithMany(p => p.PhonesEntities);
        }
    }

    public static class DataBaseControl
    {
        public static List<Phone> GetPhonesForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Phones.Include(p => p.CompanyEntity).ToList();

            }
        }

        public static void AddPhone(Phone phone)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Phones.Add(phone);
                ctx.SaveChanges();
            }
        }

        public static void UpdatePhone(Phone phone)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                Phone _phone = ctx.Phones.FirstOrDefault(p => p.Id == phone.Id);

                _phone.Title = phone.Title;
                _phone.Price = phone.Price;
                _phone.CompanyId = phone.CompanyId;

                ctx.SaveChanges();
            }
        }
    }
}

