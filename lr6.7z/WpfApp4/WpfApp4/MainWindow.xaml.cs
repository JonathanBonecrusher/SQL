﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PhoneInfo;

namespace WpfApp4
{
    public partial class MainWindow : Window
    {
        List<Phone> phones;
        public MainWindow()
        {
            InitializeComponent();
            phones = new List<Phone>
            {
                new Phone { Company = "Apple", Title = "iPhone 10", Price = 58000},
                new Phone { Company = "Xiaomi", Title = "Redmu Note 10S", Price = 28000},
                new Phone { Company = "Apple", Title = "iPhone 12 Pro Max Super Idol", Price = 158000},
                new Phone { Company = "Nokia", Title = "3310", Price = 800}
            };
            mainListBox.ItemsSource = phones;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Convert.ToDecimal(priceView.Text) <= 0 ||  titleView.Text == String.Empty || companyView.Text == String.Empty)
                {
                    throw new Exception("Неверный ввод!");
                }
                phones.Add(new Phone
                {
                    Company = companyView.Text,
                    Title = titleView.Text,
                    Price = Convert.ToDecimal(priceView.Text)
                });
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = phones;
        }

        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            Phone tempPhone = mainListBox.SelectedItem as Phone;
            if (tempPhone != null)
            {
                titleView.Text = tempPhone.Title;
                companyView.Text = tempPhone.Company;
                priceView.Text = tempPhone.Price.ToString();

                mainListBox.IsEnabled = false;
                addButtonView.IsEnabled = false;
                editButtonView.IsEnabled = false;
                removeButtonView.IsEnabled = false;

                saveEditButtonView.Visibility = Visibility.Visible;
                cancelEditButtonView.Visibility = Visibility.Visible;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                phones.Remove(mainListBox.SelectedItem as Phone);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = phones;
        }

       
        private void EndEditing()
        {
            titleView.Text = String.Empty;
            companyView.Text = String.Empty;
            priceView.Text = String.Empty;

            mainListBox.IsEnabled = true;
            addButtonView.IsEnabled = true;
            editButtonView.IsEnabled = true;
            removeButtonView.IsEnabled = true;
        }

        private void cancelEditButtonView_Click(object sender, RoutedEventArgs e) => EndEditing();

        private void saveEditButtonView_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                if (Convert.ToDecimal(priceView.Text) <= 0 ||  titleView.Text == String.Empty || companyView.Text == String.Empty)
                {
                    throw new Exception("Неверный ввод!");
                }
                Phone tempPhone = mainListBox.SelectedItem as Phone;
                tempPhone.Title = titleView.Text;
                tempPhone.Company = companyView.Text;
                tempPhone.Price = Convert.ToDecimal(priceView.Text);
            }
            catch (Exception ex)
            {
                saveEditButtonView.Visibility = Visibility.Hidden;
                cancelEditButtonView.Visibility = Visibility.Hidden;
                MessageBox.Show(ex.Message);
            }

            saveEditButtonView.Visibility = Visibility.Hidden;
            cancelEditButtonView.Visibility = Visibility.Hidden;
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = phones;

            EndEditing();
        }
    }
}
