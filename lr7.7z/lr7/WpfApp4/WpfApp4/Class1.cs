﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace PhoneInfo
{
    public class Phone
    {
        public int Id { get; set; }
        public string Title { get; set; }

        public int CompanyId { get; set; }
        public decimal Price { get; set; }

        public Company CompanyEntity { get; set; }
    }

    public class Company
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string CEO { get; set; }
        public double Capital { get; set; }

        public List<Phone> PhoneEntites { get; set; }
    }

    public class DbAppContext : DbContext
    {
        public DbSet<Phone> Phones { get; set; }
        public DbSet<Company> Company { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseNpgsql(
                "Host=localhost;Username=postgres;Password=root;Database=PhonesDatabase");

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Phone>().HasOne(p => p.CompanyEntity).WithMany(p => p.PhoneEntites);
        }
    }

    public static class DataBaseControl
    {
        public static List<Phone> GetPhonesForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Phones.Include(p => p.CompanyEntity).ToList();

            }
        }

        public static List<Company> GetCompanyForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.Company.Include(p => p.PhoneEntites).ToList();
            }
        }

        public static void AddPhone(Phone phone)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Phones.Add(phone);
                ctx.SaveChanges();
            }
        }

        public static void RemovePhone(Phone phone)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.Phones.Remove(phone);
                ctx.SaveChanges();
            }
        }

        public static void UpdatePhone(Phone phone)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                Phone _phone = ctx.Phones.FirstOrDefault(p => p.Id == phone.Id);

                try
                {
                    if (Convert.ToDecimal(phone.Price) <= 0 || phone.Title == null || phone.CompanyId == null)
                    {
                        throw new Exception("Неверный ввод!");
                    }
                    _phone.Title = phone.Title;
                    _phone.Price = phone.Price;
                    _phone.CompanyId = phone.CompanyId;
                    ctx.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            using (DbAppContext ctx = new DbAppContext())
            {
                Phone _phone = ctx.Phones.FirstOrDefault(p => p.Id == phone.Id);

                if (_phone == null)
                {
                    return;
                }

                _phone.Title = phone.Title;
                _phone.Price = phone.Price;
                _phone.CompanyId = phone.CompanyId;

                ctx.SaveChanges();
            }
        }
    }
}

